#include <stdio.h>
#include <string.h>

#define POLYNOMIAL "1101" // CRC polynomial

void xorOperation(char *dividend, const char *divisor) {
    for (int i = 0; i < strlen(divisor); i++)
        dividend[i] = (dividend[i] == divisor[i]) ? '0' : '1';
}

void computeCRC(char *data, char *remainder) {
    int dataLen = strlen(data);
    int polyLen = strlen(POLYNOMIAL);

    char temp[dataLen + 1];
    strcpy(temp, data);

    for (int i = 0; i <= dataLen - polyLen; i++) {
        if (temp[i] == '1')
            xorOperation(&temp[i], POLYNOMIAL);
    }

    strcpy(remainder, &temp[dataLen - polyLen + 1]);
}

void appendCRC(char *data) {
    int dataLen = strlen(data);
    int polyLen = strlen(POLYNOMIAL);
    char remainder[polyLen];

    strcat(data, "000"); 
    computeCRC(data, remainder);

    strncpy(&data[dataLen], remainder, polyLen - 1);
}

int detectError(char *receivedData) {
    char remainder[strlen(POLYNOMIAL)];
    computeCRC(receivedData, remainder);

    return (strchr(remainder, '1') == NULL) ? 0 : 1; 
}

int main() {
    char data[100] = "1100101";//100100";//"""1011001";  // THE THREE DIFFRENT INPUT CASES (MODIFIED)

    printf("Original Data: %s\n", data);
    appendCRC(data);
    printf("Transmitted Data with CRC: %s\n", data);

    
    if (detectError(data))
        printf("Error detected in received data!\n");
    else
        printf("No error detected. Transmission successful!\n");

    
    data[4] = (data[4] == '1') ? '0' : '1'; // Flip a bit
    printf("Received Data with Error: %s\n", data);

    if (detectError(data))
        printf("Error detected in received data!\n");
    else
        printf("No error detected. Transmission successful!\n");

    return 0;
}

