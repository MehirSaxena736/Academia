#include <stdio.h>
#include <math.h>
#include <string.h>

#define MAX 20

void calculateParityBits(int hamming[], int dataBits, int parityBits) {
    for (int i = 0; i < parityBits; i++) {
        int pos = pow(2, i);
        int parity = 0;

        for (int j = pos - 1; j < dataBits + parityBits; j += 2 * pos) {
            for (int k = j; k < j + pos && k < dataBits + parityBits; k++) {
                parity ^= hamming[k];
            }
        }
        hamming[pos - 1] = parity; 
    }
}

void encodeHamming(char data[]) {
    int dataBits = strlen(data);
    int parityBits = 0;

    
    while (pow(2, parityBits) < dataBits + parityBits + 1)
        parityBits++;

    int hamming[dataBits + parityBits];
    memset(hamming, 0, sizeof(hamming));

    
    int j = 0;
    for (int i = 0; i < dataBits + parityBits; i++) {
        if ((i & (i + 1)) == 0) 
            continue;
        hamming[i] = data[j++] - '0'; 
    }

    
    calculateParityBits(hamming, dataBits, parityBits);

    printf("Encoded Hamming Code: ");
    for (int i = 0; i < dataBits + parityBits; i++)
        printf("%d", hamming[i]);
    printf("\n");
}

int detectAndCorrectError(int received[], int totalBits) {
    int errorPos = 0;

    for (int i = 0; i < log2(totalBits) + 1; i++) {
        int pos = pow(2, i);
        int parity = 0;

        for (int j = pos - 1; j < totalBits; j += 2 * pos) {
            for (int k = j; k < j + pos && k < totalBits; k++) {
                parity ^= received[k];
            }
        }

        if (parity != 0)
            errorPos += pos; 
    }

    if (errorPos == 0) {
        printf("No errors detected.\n");
        return 0;
    } else {
        printf("Error detected at position %d. Correcting...\n", errorPos);
        received[errorPos - 1] ^= 1; 

        printf("Corrected Hamming Code: ");
        for (int i = 0; i < totalBits; i++)
            printf("%d", received[i]);
        printf("\n");

        return 1;
    }
}

int main() {
    char data[MAX];

    printf("Enter binary data: ");
    scanf("%s", data);

    encodeHamming(data);

    int received[] = {0, 1, 1, 0, 1, 0, 0}; // Example received data with error
    printf("Received Hamming Code: ");
    for (int i = 0; i < sizeof(received) / sizeof(received[0]); i++)
        printf("%d", received[i]);
    printf("\n");

    detectAndCorrectError(received, sizeof(received) / sizeof(received[0]));

    return 0;
}

